# Sistem Pinjam Pulang
Ini ialah laman statik HTML untuk sistem pinjaman dan pemulangan barang dengan sokongan QR Code. Sesuai digunakan oleh agensi, organisasi atau sekolah.
